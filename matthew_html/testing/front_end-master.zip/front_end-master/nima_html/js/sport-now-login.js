/*$(document).ready(function() {
  $("#cf_onclick").click(function() {
  $("#cf img.top").toggleClass("transparent");
});
});*/
